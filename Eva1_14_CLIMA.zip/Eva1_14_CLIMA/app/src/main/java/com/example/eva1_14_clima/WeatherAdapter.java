package com.example.eva1_14_clima;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import  android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class WeatherAdapter extends ArrayAdapter<Weather> {
    private Context context;
    private int resource;
    private Weather[] objects;

    public WeatherAdapter(@NonNull Context context, int resource, @NonNull Weather[] objects) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.objects=objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null)//primera vez que se ejecuta la app, crear las filas
            //inflar, inflate
        convertView = ((Activity)context).getLayoutInflater().inflate(resource,parent,false);
        TextView textViewcity, textViewtemp, textViewdesc;
        ImageView imagenviewimagen;
        textViewcity=convertView.findViewById(R.id.textViewcity);
        textViewtemp=convertView.findViewById(R.id.textViewtemp);
        textViewdesc=convertView.findViewById(R.id.textViewdesc);
        imagenviewimagen=convertView.findViewById(R.id.imagenviewimagen);

        textViewcity.setText(objects[position].getCiudad());
        textViewtemp.setText(objects[position].getTemp()+" °C");
        textViewdesc.setText(objects[position].getDesc());
        imagenviewimagen.setImageResource(objects[position].getImagenclima());

    return convertView;
    }
    //layout creado a traves de convert view
}
