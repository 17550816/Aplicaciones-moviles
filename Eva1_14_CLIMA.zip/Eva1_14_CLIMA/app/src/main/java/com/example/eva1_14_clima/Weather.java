package com.example.eva1_14_clima;

public class Weather {
    private String ciudad;
    private double temp;
    private String desc;
    private int imagenclima;

    public Weather() {
    }

    public Weather(String ciudad, double temp, String desc, int imagenclima) {
        this.ciudad = ciudad;
        this.temp = temp;
        this.desc = desc;
        this.imagenclima = imagenclima;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public double getTemp() {
        return temp;
    }

    public void setTemp(double temp) {
        this.temp = temp;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getImagenclima() {
        return imagenclima;
    }

    public void setImagenclima(int imagenclima) {
        this.imagenclima = imagenclima;
    }
}
