package com.example.eva1_14_clima;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
Weather[] wheaters= {
  new Weather("Chihuahua",20, "Lluvia lijera", R.drawable.light_rain),
        new Weather("Juarez",4.5, "Despejado", R.drawable.atmospher),
        new Weather("Parral",7.5, "Nublado", R.drawable.cloudy),
        new Weather("Jimnez",8.5, "Lluvioso", R.drawable.rainy),
        new Weather("Cuauhtemoc",22, "Tormenta electrica", R.drawable.thunderstorm),
        new Weather("Camargo",12.4, "Tornado", R.drawable.tornado),
        new Weather("Aldama",6.5, "Nublado", R.drawable.cloudy),
        new Weather("Casas Grandes",12, "Tormenta electrica", R.drawable.thunderstorm),
        new Weather("Ojinaga",14, "Nevada", R.drawable.snow)
};
ListView listaClima;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaClima.findViewById(R.id.listaClima);
        listaClima.setAdapter(new WeatherAdapter(
                this,
                R.layout.layout_clima,
                wheaters
        ));
    }
}