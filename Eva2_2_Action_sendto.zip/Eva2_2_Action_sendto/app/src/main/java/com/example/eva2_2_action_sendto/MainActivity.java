package com.example.eva2_2_action_sendto;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText mes, tel;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tel = findViewById(R.id.tel);
        mes = findViewById(R.id.mes);
    }
    public void onClick(View v){
        String sTel = "smsto:" + tel.getText().toString();
        String smes = tel.getText().toString();
        intent= new Intent(Intent.ACTION_SENDTO, Uri.parse(sTel));
        intent.putExtra("sms_body",smes);
        startActivity(intent);

    }

}