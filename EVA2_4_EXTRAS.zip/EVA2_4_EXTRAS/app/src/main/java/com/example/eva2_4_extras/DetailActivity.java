package com.example.eva2_4_extras;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {

    TextView Datos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Datos = findViewById(R.id.Datos);
        Intent intent = getIntent();
        Datos.append(intent.getStringExtra("MENSAJE"));
        Datos.append(""+intent.getIntExtra("ENTERO", 0));
        Datos.append(""+intent.getFloatExtra("PRECIO",0.0f));
    }
}