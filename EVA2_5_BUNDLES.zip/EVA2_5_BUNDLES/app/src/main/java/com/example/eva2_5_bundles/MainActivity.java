package com.example.eva2_5_bundles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    String[] datos = {
      "Chihuahua",
      "Parral",
            "Delicias",
            "Juarez",
            "Camargo",
            "Jimenez",
            "Casas Grandes",
            "Durango",
            "Hermosillo",
            "Obregon",
            "Mexicali",
            "Nogales",
            "Satillo",
            "Torreon",
            "Piedras Negras",
            "Monterrey",
            "Acuña",
            "Tampico",
            "Aldama"
 };
    Intent intent;
    ListView listaDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listaDatos = findViewById(R.id.listaDatos);
        intent = new Intent(this, DetailActivity.class);
        listaDatos.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,datos));
        listaDatos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Bundle bundle = new Bundle();
                bundle.putString("CIUDAD",datos[i]);
                bundle.putInt("POSICION",i);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

    }
}