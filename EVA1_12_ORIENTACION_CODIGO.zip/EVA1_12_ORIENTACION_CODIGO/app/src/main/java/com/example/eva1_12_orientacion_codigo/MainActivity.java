package com.example.eva1_12_orientacion_codigo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
implements View.OnClickListener{

Button botonact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        botonact = findViewById(R.id.botonact);
        botonact.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int orienta = getResources().getConfiguration().orientation;
        if (orienta == Configuration.ORIENTATION_PORTRAIT)
        Toast.makeText(this, "Modo portrait", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(this, "Modo landscape", Toast.LENGTH_SHORT).show();
    }
}