package com.example.eva1_7_eventos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
implements View.OnClickListener{


    Button btnLnListener, btclaseAnon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLnListener = findViewById(R.id.btnLnListener);
        btnLnListener.setOnClickListener(this);
        btclaseAnon = findViewById(R.id.btclaseAnon);
final Context context = getApplicationContext();
        btclaseAnon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Por clase anonima ", Toast.LENGTH_SHORT).show();
            }
        });

    }
    public void miClick (View v){
        Toast.makeText(this, "Error en el sistema, hora de restaurar", Toast.LENGTH_SHORT).show();
        Log.wtf("Mensaje","Falla catastrofica");


    }
        public void onClick(View v) {
            Toast.makeText(this, "Evento por interfaz", Toast.LENGTH_SHORT).show();
        }
}