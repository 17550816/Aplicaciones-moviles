package com.example.eva1_9_idiomas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
RadioGroup idioma,rgsexo;
RadioButton español,ingles,mucho,poco,nada;
TextView nombre,apellido,sexo;
EditText intnombre,intapellido;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        idioma = findViewById(R.id.idioma);
        español = findViewById(R.id.español);
        ingles = findViewById(R.id.ingles);
        rgsexo = findViewById(R.id.rgsexo);
        mucho= findViewById(R.id.mucho);
        poco= findViewById(R.id.poco);
        nada= findViewById(R.id.nada);
        nombre= findViewById(R.id.nombre);
        apellido= findViewById(R.id.apellido);
        sexo= findViewById(R.id.sexo);
        intnombre= findViewById(R.id.intnombre);
        intapellido= findViewById(R.id.intapellido);


        idioma.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(RadioGroup radioGroup, int i) {
                        if (i ==R.id.español){
                            español.setText(R.string.btn_es_español);
                            ingles.setText(R.string.bt_es_ingles);
                            nombre.setText(R.string.txt_es_nombre);
                            intnombre.setHint(R.string.hint_es_nombre);
                            apellido.setText(R.string.txt_es_apellido);
                            intapellido.setHint(R.string.hint_es_apellido);
                            sexo.setText(R.string.txt_es_sexo);
                            mucho.setText(R.string.btn_es_mucho);
                            poco.setText(R.string.btn_es_poco);
                            nada.setText(R.string.btn_es_nada);
                        }else if (i==R.id.ingles){
                            español.setText(R.string.btn_en_español);
                            ingles.setText(R.string.bt_en_ingles);
                            nombre.setText(R.string.txt_en_nombre);
                            intnombre.setHint(R.string.hint_en_nombre);
                            apellido.setText(R.string.txt_en_apellido);
                            intapellido.setHint(R.string.hint_en_apellido);
                            sexo.setText(R.string.txt_en_sexo);
                            mucho.setText(R.string.btn_en_mucho);
                            poco.setText(R.string.btn_en_poco);
                            nada.setText(R.string.btn_en_nada);
                        }
                      }
                }
        );
    }
}